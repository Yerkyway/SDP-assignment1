public class Truck extends Transport{

    private String capacityOfTransport;

    private String deliveryTime;

    public Truck(String capacityOfTransport, String deliveryTime) {
        this.capacityOfTransport=capacityOfTransport;
        this.deliveryTime=deliveryTime;
    }

    @Override
    public String capacityOfTransport() {
        return this.capacityOfTransport;
    }

    @Override
    public String deliveryTime() {
        return this.deliveryTime;
    }
}
