public abstract class Transport {

    public abstract String capacityOfTransport();

    public abstract String deliveryTime();


    public String toString() {
        return "Capacity of transport: "+this.capacityOfTransport() +"\nDelivery time: "+this.deliveryTime();
    }
}
