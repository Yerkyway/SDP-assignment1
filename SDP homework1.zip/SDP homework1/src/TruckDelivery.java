public class TruckDelivery implements ILogisticApp{

    private String capacityOfTransport;

    private String deliveryTime;

    public TruckDelivery(String capacityOfTransport, String deliveryTime) {
        this.capacityOfTransport=capacityOfTransport;
        this.deliveryTime=deliveryTime;
    }

    @Override
    public Transport deliver() {
        return new Truck(capacityOfTransport, deliveryTime);
    }
}
