public class Ship extends Transport{

    private String capacityOfTransport;

    private String deliveryTime;

    public Ship(String capacityOfTransport, String deliveryTime) {
        this.capacityOfTransport=capacityOfTransport;
        this.deliveryTime=deliveryTime;
    }

    @Override
    public String capacityOfTransport() {
        return this.capacityOfTransport;
    }

    @Override
    public String deliveryTime() {
        return this.deliveryTime;
    }
}
