public class TestLogistic {
    public static void main(String[] args) {
        test();
    }

    public static void test() {
        Transport ship = TransportF.getTransport(new ShipDelivery("10000 TEUs", "1 month"));
        Transport truck = TransportF.getTransport(new TruckDelivery("25 tonnes", "1-2 week"));
        System.out.println("Ship's capacity and time: "+ship);
        System.out.println("Truck's capacity and time: "+truck);
    }
}
