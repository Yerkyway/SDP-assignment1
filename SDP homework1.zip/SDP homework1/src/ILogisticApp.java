public interface ILogisticApp {
    Transport deliver();
}
