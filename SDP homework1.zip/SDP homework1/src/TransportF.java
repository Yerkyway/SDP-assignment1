public class TransportF {
    public static Transport getTransport( ILogisticApp logisticApp) {
        return logisticApp.deliver();
    }
}
