public class ShipDelivery implements ILogisticApp{

    private String capacityOfTransport;

    private String deliveryTime;

    public ShipDelivery(String capacityOfTransport, String deliveryTime) {
        this.capacityOfTransport=capacityOfTransport;
        this.deliveryTime=deliveryTime;
    }

    @Override
    public Transport deliver() {
        return new Ship(capacityOfTransport, deliveryTime);
    }
}
